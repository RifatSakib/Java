package project;
public class demo
{
public void massage()
{System.out.println("Welcome");
}
}