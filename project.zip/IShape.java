public interface IShape
{
      public void show();

   
   public static void message()
   {
    System.out.println (" its interface");
   }



} 