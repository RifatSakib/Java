package classes;

public class EmailException extends Exception{
	
	
	public EmailException(String msg)
	{
		
		super(msg);
	}
	
	
	
	
}