package Interfaces;

public interface visaInfo{


public double feeCalculation(String country,String entry);


}