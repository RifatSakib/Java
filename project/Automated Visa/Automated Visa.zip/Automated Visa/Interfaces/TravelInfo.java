package Interfaces;

public interface TravelInfo {
    

    String getPassportNo();
    String getPassportDate();
	String getPassportExpierydate();
    String getPreviousVisit();

}
