package Interfaces;

public interface PersonalInfo {

    public String getName();
    public String getpAdress();
    public String getContactNo();
    public String getAdressInBd();
    public String getBdContactNo();
    public String getBdContactEmail();
    public String getDob();
    public String getSex();
    public String getPlaceOfBirth();
    public String getNationality();
	public String getOccupation();
    public String getMaritalStatus();
}

